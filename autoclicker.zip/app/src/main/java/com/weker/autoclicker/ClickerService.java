package com.weker.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ClickerService extends AccessibilityService {

    static ClickerService instance;

    private static final int TYPE = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    private static final int NOT_FOCUSABLE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    private static final int NOT_TOUCHABLE = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;

    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());

    private LinearLayout panel, body;
    private WindowManager.LayoutParams panelLp;
    private View catcher;
    private WindowManager.LayoutParams catcherLp;
    private TextView grip, status;
    private Button btnRec, btnPlay, btnMin;
    private EditText etDelay, etRepeat, etPause;

    // точка: x1, y1, x2, y2, задержка перед ней (мс), длительность нажатия (мс)
    private final ArrayList<long[]> pts = new ArrayList<>();
    private boolean recording, playing, passing, panelShown;
    private long lastUp, downT;
    private float downX, downY;
    private int step, cycle;
    private long fixedDelay, repeat, pause;

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        sp = getSharedPreferences("clicker", MODE_PRIVATE);
        loadPattern();
        showPanel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        hidePanel();
        instance = null;
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ===================== ПАНЕЛЬ =====================

    void showPanel() {
        if (panelShown) return;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE1B1B2A);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF7C5CFF);
        panel.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        grip = new TextView(this);
        grip.setText("⠿ Кликер");
        grip.setTextColor(Color.WHITE);
        grip.setTextSize(14);
        grip.setPadding(dp(4), dp(8), dp(10), dp(8));
        head.addView(grip, new LinearLayout.LayoutParams(-2, -2));

        View spacer = new View(this);
        head.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));

        btnPlay = btn("▶", 0xFF2E9E5B, v -> {
            if (playing) stopPlay("Остановлено");
            else startPlay();
        });
        btnMin = btn("—", 0xFF3A3A55, v -> toggleBody());
        Button btnClose = btn("✕", 0xFF8A2E3B, v -> hidePanel());
        head.addView(btnPlay, margin());
        head.addView(btnMin, margin());
        head.addView(btnClose, margin());
        panel.addView(head);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setTextColor(0xFFDCD6FF);
        status.setTextSize(12);
        status.setPadding(dp(2), dp(4), dp(2), dp(6));
        body.addView(status);

        btnRec = btn("● Записать паттерн", 0xFFB23A48, v -> {
            if (recording) stopRecord();
            else startRecord();
        });
        body.addView(btnRec, new LinearLayout.LayoutParams(-1, -2));

        etDelay = field("Задержка между кликами, мс (0 = как записал)", "delay", 0);
        etRepeat = field("Сколько циклов (0 = бесконечно)", "repeat", 0);
        etPause = field("Пауза между циклами, мс", "pause", 500);

        Button btnClear = btn("Очистить паттерн", 0xFF3A3A55, v -> {
            if (playing) stopPlay("");
            pts.clear();
            savePattern();
            updateStatus();
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.topMargin = dp(8);
        body.addView(btnClear, clp);

        panel.addView(body);

        grip.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelLp.x;
                        sy = panelLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = sx + (int) (e.getRawX() - tx);
                        panelLp.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelLp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        sp.edit().putInt("px", panelLp.x).putInt("py", panelLp.y).apply();
                        return true;
                }
                return false;
            }
        });

        panelLp = new WindowManager.LayoutParams(
                dp(260), WindowManager.LayoutParams.WRAP_CONTENT, TYPE,
                NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = sp.getInt("px", dp(16));
        panelLp.y = sp.getInt("py", dp(120));
        wm.addView(panel, panelLp);
        panelShown = true;
        updateStatus();
    }

    void hidePanel() {
        if (recording) stopRecord();
        if (playing) stopPlay("");
        if (panelShown && panel != null) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
        }
        panelShown = false;
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(4);
        return lp;
    }

    private Button btn(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private EditText field(String label, String key, long def) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFB8B8D0);
        t.setTextSize(11);
        t.setPadding(0, dp(8), 0, dp(3));
        body.addView(t);

        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setText(String.valueOf(sp.getLong(key, def)));
        e.setTextColor(Color.WHITE);
        e.setTextSize(14);
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2C2C42);
        g.setCornerRadius(dp(8));
        e.setBackground(g);
        e.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                setPanelFocusable(true);
                h.postDelayed(() -> {
                    v.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(v, 0);
                }, 80);
            }
            return false;
        });
        body.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void setPanelFocusable(boolean f) {
        if (!panelShown) return;
        if (f) {
            panelLp.flags &= ~NOT_FOCUSABLE;
        } else {
            panelLp.flags |= NOT_FOCUSABLE;
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(panel.getWindowToken(), 0);
            panel.clearFocus();
        }
        wm.updateViewLayout(panel, panelLp);
    }

    private void toggleBody() {
        setPanelFocusable(false);
        if (body.getVisibility() == View.VISIBLE) {
            body.setVisibility(View.GONE);
            panelLp.width = WindowManager.LayoutParams.WRAP_CONTENT;
            btnMin.setText("□");
        } else {
            body.setVisibility(View.VISIBLE);
            panelLp.width = dp(260);
            btnMin.setText("—");
        }
        wm.updateViewLayout(panel, panelLp);
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        String s;
        String shortS;
        if (recording) {
            s = "Запись… тапай по экрану, клики проходят насквозь. Точек: " + pts.size();
            shortS = "● " + pts.size();
        } else if (playing) {
            int shown = Math.min(step + 1, pts.size());
            s = "Цикл " + (cycle + 1) + (repeat > 0 ? "/" + repeat : "/∞") + "   клик " + shown + "/" + pts.size();
            shortS = "▶ " + (cycle + 1) + (repeat > 0 ? "/" + repeat : "");
        } else {
            s = "Точек в паттерне: " + pts.size();
            shortS = "⠿";
        }
        status.setText(s);
        boolean collapsed = body.getVisibility() != View.VISIBLE;
        grip.setText(collapsed ? shortS : "⠿ Кликер");
    }

    // ===================== ЗАПИСЬ =====================

    private void startRecord() {
        if (playing) stopPlay("");
        setPanelFocusable(false);
        pts.clear();
        recording = true;
        passing = false;
        lastUp = SystemClock.uptimeMillis();

        catcher = new View(this);
        catcher.setBackgroundColor(0x2233FF99);
        catcherLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, TYPE,
                NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        catcherLp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            catcherLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        catcher.setOnTouchListener((v, e) -> {
            onCatch(e);
            return true;
        });
        wm.addView(catcher, catcherLp);

        wm.removeView(panel);
        wm.addView(panel, panelLp);

        btnRec.setText("■ Закончить запись");
        updateStatus();
    }

    private void stopRecord() {
        recording = false;
        passing = false;
        if (catcher != null) {
            try {
                wm.removeView(catcher);
            } catch (Exception ignored) {
            }
            catcher = null;
        }
        savePattern();
        btnRec.setText("● Записать паттерн");
        updateStatus();
    }

    private void onCatch(MotionEvent e) {
        if (passing) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downT = SystemClock.uptimeMillis();
                downX = e.getRawX();
                downY = e.getRawY();
                break;
            case MotionEvent.ACTION_UP:
                long now = SystemClock.uptimeMillis();
                long dur = Math.max(10, Math.min(now - downT, 59000));
                float ux = e.getRawX();
                float uy = e.getRawY();
                if (Math.hypot(ux - downX, uy - downY) < dp(20)) {
                    ux = downX;
                    uy = downY;
                }
                long delay = pts.isEmpty() ? 0 : Math.max(0, downT - lastUp);
                long[] p = {(long) downX, (long) downY, (long) ux, (long) uy, delay, dur};
                pts.add(p);
                updateStatus();
                passThrough(p);
                break;
        }
    }

    private void passThrough(long[] p) {
        passing = true;
        catcherLp.flags |= NOT_TOUCHABLE;
        wm.updateViewLayout(catcher, catcherLp);
        h.postDelayed(() -> gesture(p, () -> {
            if (catcher != null) {
                catcherLp.flags &= ~NOT_TOUCHABLE;
                wm.updateViewLayout(catcher, catcherLp);
            }
            passing = false;
            lastUp = SystemClock.uptimeMillis();
        }), 60);
    }

    // ===================== ВОСПРОИЗВЕДЕНИЕ =====================

    private void startPlay() {
        if (recording) stopRecord();
        if (pts.isEmpty()) {
            if (body.getVisibility() != View.VISIBLE) toggleBody();
            status.setText("Сначала запиши паттерн (● Записать)");
            return;
        }
        fixedDelay = num(etDelay, "delay");
        repeat = num(etRepeat, "repeat");
        pause = num(etPause, "pause");
        setPanelFocusable(false);
        playing = true;
        step = 0;
        cycle = 0;
        btnPlay.setText("■");
        if (body.getVisibility() == View.VISIBLE) toggleBody();
        updateStatus();
        h.postDelayed(this::next, 500);
    }

    private void next() {
        if (!playing) return;
        if (step >= pts.size()) {
            step = 0;
            cycle++;
            if (repeat > 0 && cycle >= repeat) {
                stopPlay("Готово: " + cycle + " цикл(ов)");
                return;
            }
            updateStatus();
            h.postDelayed(this::next, pause);
            return;
        }
        long[] p = pts.get(step);
        long wait = step == 0 ? 0 : (fixedDelay > 0 ? fixedDelay : p[4]);
        h.postDelayed(() -> {
            if (!playing) return;
            gesture(p, () -> {
                step++;
                updateStatus();
                next();
            });
        }, wait);
    }

    private void stopPlay(String msg) {
        playing = false;
        h.removeCallbacksAndMessages(null);
        btnPlay.setText("▶");
        updateStatus();
        if (msg != null && !msg.isEmpty()) status.setText(msg);
    }

    private void gesture(long[] p, Runnable done) {
        Path path = new Path();
        path.moveTo(Math.max(0, p[0]), Math.max(0, p[1]));
        if (p[0] != p[2] || p[1] != p[3]) path.lineTo(Math.max(0, p[2]), Math.max(0, p[3]));
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, p[5]))
                .build();
        boolean ok = dispatchGesture(g, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription d) {
                done.run();
            }

            @Override
            public void onCancelled(GestureDescription d) {
                done.run();
            }
        }, h);
        if (!ok) h.postDelayed(done, 100);
    }

    // ===================== СОХРАНЕНИЕ =====================

    private long num(EditText e, String key) {
        long v;
        try {
            v = Long.parseLong(e.getText().toString().trim());
        } catch (Exception x) {
            v = 0;
        }
        if (v < 0) v = 0;
        e.setText(String.valueOf(v));
        sp.edit().putLong(key, v).apply();
        return v;
    }

    private void savePattern() {
        StringBuilder sb = new StringBuilder();
        for (long[] p : pts) {
            for (int i = 0; i < 6; i++) {
                sb.append(p[i]).append(i < 5 ? ',' : ';');
            }
        }
        sp.edit().putString("pattern", sb.toString()).apply();
    }

    private void loadPattern() {
        pts.clear();
        String s = sp.getString("pattern", "");
        for (String part : s.split(";")) {
            String[] a = part.split(",");
            if (a.length != 6) continue;
            try {
                long[] p = new long[6];
                for (int i = 0; i < 6; i++) p[i] = Long.parseLong(a[i].trim());
                pts.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
