package com.weker.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

public class ClickerService extends AccessibilityService {

    static ClickerService instance;

    private static final int TYPE = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    private static final int NOT_FOCUSABLE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    private static final int NOT_TOUCHABLE = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
    private static final int IN_SCREEN = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    private static final int COL_MARK = 0xDD7C5CFF;
    private static final int COL_NOW = 0xFF2E9E5B;
    private static final int COL_EDIT = 0xFFE09B2D;

    // клик: x1, y1, x2, y2, пауза перед (мс), длительность (мс), сколько раз, интервал между повторами (мс)
    private static final int X1 = 0, Y1 = 1, X2 = 2, Y2 = 3, DELAY = 4, DUR = 5, TIMES = 6, GAP = 7;

    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());

    private LinearLayout panel, body, listBox, editor;
    private ScrollView listScroll;
    private WindowManager.LayoutParams panelLp;
    private View catcher;
    private WindowManager.LayoutParams catcherLp;
    private TextView grip, status, editTitle;
    private Button btnRec, btnPlay, btnMin, btnEye;
    private EditText etCycles, etPause, etTimes, etDelay, etGap, etDur;

    private final ArrayList<long[]> pts = new ArrayList<>();
    private final ArrayList<TextView> markers = new ArrayList<>();
    private final ArrayList<WindowManager.LayoutParams> markerLps = new ArrayList<>();
    private final ArrayList<TextView> rows = new ArrayList<>();

    private boolean recording, playing, passing, panelShown, showMarks = true;
    private long lastUp, downT;
    private float downX, downY;
    private int step, rep, cycle, editIdx = -1;
    private long cycles, pause;

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        sp = getSharedPreferences("clicker", MODE_PRIVATE);
        showMarks = sp.getBoolean("marks", true);
        loadPattern();
        showPanel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        hidePanel();
        instance = null;
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void fullScreen(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= 30) {
            lp.setFitInsetsTypes(0);
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }

    // ===================== ПАНЕЛЬ =====================

    void showPanel() {
        if (panelShown) return;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE1B1B2A);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF7C5CFF);
        panel.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        grip = new TextView(this);
        grip.setText("⠿ Кликер");
        grip.setTextColor(Color.WHITE);
        grip.setTextSize(14);
        grip.setPadding(dp(4), dp(8), dp(10), dp(8));
        head.addView(grip, new LinearLayout.LayoutParams(-2, -2));
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        btnPlay = btn("▶", 0xFF2E9E5B, v -> {
            if (playing) stopPlay("Остановлено");
            else startPlay();
        });
        btnMin = btn("—", 0xFF3A3A55, v -> toggleBody());
        Button btnClose = btn("✕", 0xFF8A2E3B, v -> hidePanel());
        head.addView(btnPlay, margin());
        head.addView(btnMin, margin());
        head.addView(btnClose, margin());
        panel.addView(head);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setTextColor(0xFFDCD6FF);
        status.setTextSize(12);
        status.setPadding(dp(2), dp(4), dp(2), dp(6));
        body.addView(status);

        btnRec = btn("● Записать клики", 0xFFB23A48, v -> {
            if (recording) stopRecord();
            else startRecord();
        });
        body.addView(btnRec, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.addView(btn("+ Клик", 0xFF3A3A55, v -> addClick()), weight());
        btnEye = btn(showMarks ? "Метки: вкл" : "Метки: выкл", 0xFF3A3A55, v -> {
            showMarks = !showMarks;
            sp.edit().putBoolean("marks", showMarks).apply();
            btnEye.setText(showMarks ? "Метки: вкл" : "Метки: выкл");
            refreshMarkers();
        });
        tools.addView(btnEye, weight());
        tools.addView(btn("Очистить", 0xFF3A3A55, v -> {
            if (playing) stopPlay("");
            closeEditor();
            pts.clear();
            savePattern();
            refreshMarkers();
            rebuildList();
        }), weight());
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.topMargin = dp(6);
        body.addView(tools, tlp);

        label(body, "Клики (нажми на клик или метку, чтобы настроить):");
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listScroll = new ScrollView(this);
        listScroll.addView(listBox);
        body.addView(listScroll, new LinearLayout.LayoutParams(-1, -2));

        editor = new LinearLayout(this);
        editor.setOrientation(LinearLayout.VERTICAL);
        editor.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable eg = new GradientDrawable();
        eg.setColor(0xFF24243A);
        eg.setCornerRadius(dp(10));
        eg.setStroke(dp(1), COL_EDIT);
        editor.setBackground(eg);
        editTitle = new TextView(this);
        editTitle.setTextColor(COL_EDIT);
        editTitle.setTextSize(14);
        editTitle.setPadding(0, dp(4), 0, 0);
        editor.addView(editTitle);
        etTimes = field(editor, "Сколько раз нажать подряд", 1);
        etDelay = field(editor, "Пауза перед этим кликом, мс", 0);
        etGap = field(editor, "Интервал между повторами, мс", 100);
        etDur = field(editor, "Длительность нажатия, мс", 50);
        LinearLayout eb = new LinearLayout(this);
        eb.setOrientation(LinearLayout.HORIZONTAL);
        eb.addView(btn("Сохранить", 0xFF2E9E5B, v -> saveEditor()), weight());
        eb.addView(btn("Удалить", 0xFF8A2E3B, v -> deleteClick()), weight());
        eb.addView(btn("Назад", 0xFF3A3A55, v -> closeEditor()), weight());
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(8);
        editor.addView(eb, elp);
        editor.setVisibility(View.GONE);
        LinearLayout.LayoutParams edlp = new LinearLayout.LayoutParams(-1, -2);
        edlp.topMargin = dp(6);
        body.addView(editor, edlp);

        etCycles = field(body, "Сколько циклов (0 = бесконечно)", sp.getLong("repeat", 0));
        etPause = field(body, "Пауза между циклами, мс", sp.getLong("pause", 500));

        panel.addView(body);

        grip.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelLp.x;
                        sy = panelLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = sx + (int) (e.getRawX() - tx);
                        panelLp.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelLp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        sp.edit().putInt("px", panelLp.x).putInt("py", panelLp.y).apply();
                        return true;
                }
                return false;
            }
        });

        panelLp = new WindowManager.LayoutParams(
                dp(280), WindowManager.LayoutParams.WRAP_CONTENT, TYPE,
                NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = sp.getInt("px", dp(16));
        panelLp.y = sp.getInt("py", dp(120));
        wm.addView(panel, panelLp);
        panelShown = true;
        rebuildList();
        refreshMarkers();
        updateStatus();
    }

    void hidePanel() {
        if (recording) stopRecord();
        if (playing) stopPlay("");
        removeMarkers();
        if (panelShown && panel != null) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
        }
        panelShown = false;
    }

    private void panelToFront() {
        if (!panelShown) return;
        try {
            wm.removeView(panel);
            wm.addView(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(4);
        return lp;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        return lp;
    }

    private Button btn(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), dp(7), dp(8), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private void label(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFB8B8D0);
        t.setTextSize(11);
        t.setPadding(0, dp(8), 0, dp(3));
        parent.addView(t);
    }

    private EditText field(LinearLayout parent, String text, long value) {
        label(parent, text);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setText(String.valueOf(value));
        e.setTextColor(Color.WHITE);
        e.setTextSize(14);
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2C2C42);
        g.setCornerRadius(dp(8));
        e.setBackground(g);
        e.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                setPanelFocusable(true);
                h.postDelayed(() -> {
                    v.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(v, 0);
                }, 80);
            }
            return false;
        });
        parent.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void setPanelFocusable(boolean f) {
        if (!panelShown) return;
        if (f) {
            panelLp.flags &= ~NOT_FOCUSABLE;
        } else {
            panelLp.flags |= NOT_FOCUSABLE;
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(panel.getWindowToken(), 0);
            panel.clearFocus();
        }
        wm.updateViewLayout(panel, panelLp);
    }

    private void toggleBody() {
        setPanelFocusable(false);
        if (body.getVisibility() == View.VISIBLE) {
            body.setVisibility(View.GONE);
            panelLp.width = WindowManager.LayoutParams.WRAP_CONTENT;
            btnMin.setText("□");
        } else {
            body.setVisibility(View.VISIBLE);
            panelLp.width = dp(280);
            btnMin.setText("—");
        }
        wm.updateViewLayout(panel, panelLp);
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        String s;
        String shortS;
        int n = pts.size();
        if (recording) {
            s = "Запись… тапай по экрану, клики проходят насквозь. Кликов: " + n;
            shortS = "● " + n;
        } else if (playing && n > 0) {
            int i = Math.min(step, n - 1);
            long times = pts.get(i)[TIMES];
            s = "Клик " + (i + 1) + "/" + n + "  ·  нажатие " + Math.min(rep + 1, times) + "/" + times
                    + "  ·  цикл " + (cycle + 1) + (cycles > 0 ? "/" + cycles : "/∞");
            shortS = "▶ #" + (i + 1) + " " + Math.min(rep + 1, times) + "/" + times;
        } else {
            s = n == 0 ? "Кликов нет. Запиши их или добавь «+ Клик»." : "Кликов в паттерне: " + n;
            shortS = "⠿";
        }
        status.setText(s);
        boolean collapsed = body.getVisibility() != View.VISIBLE;
        grip.setText(collapsed ? shortS : "⠿ Кликер");
    }

    // ===================== МЕТКИ НА ЭКРАНЕ =====================

    private void removeMarkers() {
        for (TextView m : markers) {
            try {
                wm.removeView(m);
            } catch (Exception ignored) {
            }
        }
        markers.clear();
        markerLps.clear();
    }

    private void refreshMarkers() {
        removeMarkers();
        if (!panelShown || !showMarks) {
            paintList();
            return;
        }
        for (int i = 0; i < pts.size(); i++) addMarker(i);
        panelToFront();
        paintMarkers();
    }

    private void addMarker(int idx) {
        if (!panelShown || !showMarks) return;
        int size = dp(34);
        long[] p = pts.get(idx);
        TextView m = new TextView(this);
        m.setGravity(Gravity.CENTER);
        m.setTextColor(Color.WHITE);
        m.setTextSize(13);
        m.setText(String.valueOf(idx + 1));
        m.setBackground(circle(COL_MARK));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                size, size, TYPE,
                NOT_FOCUSABLE | IN_SCREEN | ((recording || playing) ? NOT_TOUCHABLE : 0),
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) p[X1] - size / 2;
        lp.y = (int) p[Y1] - size / 2;
        fullScreen(lp);

        m.setOnTouchListener(new View.OnTouchListener() {
            float tx, ty;
            int sx, sy;
            boolean drag;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        tx = e.getRawX();
                        ty = e.getRawY();
                        sx = lp.x;
                        sy = lp.y;
                        drag = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx;
                        float dy = e.getRawY() - ty;
                        if (!drag && Math.hypot(dx, dy) > dp(8)) drag = true;
                        if (drag) {
                            lp.x = sx + (int) dx;
                            lp.y = sy + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (idx >= pts.size()) return true;
                        if (drag) {
                            long[] q = pts.get(idx);
                            long ddx = (lp.x + size / 2) - q[X1];
                            long ddy = (lp.y + size / 2) - q[Y1];
                            q[X1] += ddx;
                            q[Y1] += ddy;
                            q[X2] += ddx;
                            q[Y2] += ddy;
                            savePattern();
                        } else {
                            openEditor(idx);
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(m, lp);
        markers.add(m);
        markerLps.add(lp);
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(2), Color.WHITE);
        return g;
    }

    private void paintMarkers() {
        for (int i = 0; i < markers.size(); i++) {
            int c = COL_MARK;
            if (playing && i == step) c = COL_NOW;
            else if (i == editIdx) c = COL_EDIT;
            markers.get(i).setBackground(circle(c));
            float s = (playing && i == step) ? 1.25f : 1f;
            markers.get(i).setScaleX(s);
            markers.get(i).setScaleY(s);
        }
        paintList();
    }

    // ===================== СПИСОК И НАСТРОЙКА КЛИКА =====================

    private void rebuildList() {
        if (listBox == null) return;
        listBox.removeAllViews();
        rows.clear();
        for (int i = 0; i < pts.size(); i++) {
            final int idx = i;
            long[] p = pts.get(i);
            TextView r = new TextView(this);
            String kind = (p[X1] != p[X2] || p[Y1] != p[Y2]) ? "свайп" : "тап";
            r.setText((i + 1) + ".  " + kind + "  ×" + p[TIMES] + "   пауза " + p[DELAY] + " мс");
            r.setTextColor(Color.WHITE);
            r.setTextSize(13);
            r.setPadding(dp(10), dp(8), dp(10), dp(8));
            r.setOnClickListener(v -> openEditor(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(3);
            listBox.addView(r, lp);
            rows.add(r);
        }
        fitListHeight();
        paintList();
        updateStatus();
    }

    private void fitListHeight() {
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) listScroll.getLayoutParams();
        lp.height = pts.size() > 4 ? dp(170) : LinearLayout.LayoutParams.WRAP_CONTENT;
        listScroll.setLayoutParams(lp);
    }

    private void paintList() {
        for (int i = 0; i < rows.size(); i++) {
            int c = 0xFF2C2C42;
            if (playing && i == step) c = COL_NOW;
            else if (i == editIdx) c = COL_EDIT;
            GradientDrawable g = new GradientDrawable();
            g.setColor(c);
            g.setCornerRadius(dp(8));
            rows.get(i).setBackground(g);
        }
        if (playing && step < rows.size() && listScroll != null) {
            View r = rows.get(step);
            listScroll.post(() -> listScroll.smoothScrollTo(0, r.getTop()));
        }
    }

    private void openEditor(int idx) {
        if (recording || idx < 0 || idx >= pts.size()) return;
        if (playing) stopPlay("");
        if (body.getVisibility() != View.VISIBLE) toggleBody();
        editIdx = idx;
        long[] p = pts.get(idx);
        editTitle.setText("Клик #" + (idx + 1) + "  (метку можно перетаскивать)");
        etTimes.setText(String.valueOf(p[TIMES]));
        etDelay.setText(String.valueOf(p[DELAY]));
        etGap.setText(String.valueOf(p[GAP]));
        etDur.setText(String.valueOf(p[DUR]));
        editor.setVisibility(View.VISIBLE);
        listScroll.setVisibility(View.GONE);
        paintMarkers();
    }

    private void closeEditor() {
        editIdx = -1;
        if (editor == null) return;
        setPanelFocusable(false);
        editor.setVisibility(View.GONE);
        listScroll.setVisibility(View.VISIBLE);
        paintMarkers();
    }

    private void saveEditor() {
        if (editIdx < 0 || editIdx >= pts.size()) {
            closeEditor();
            return;
        }
        long[] p = pts.get(editIdx);
        p[TIMES] = parse(etTimes, 1, 100000, 1);
        p[DELAY] = parse(etDelay, 0, 3600000, 0);
        p[GAP] = parse(etGap, 0, 3600000, 100);
        p[DUR] = parse(etDur, 10, 59000, 50);
        savePattern();
        closeEditor();
        rebuildList();
    }

    private void deleteClick() {
        if (editIdx >= 0 && editIdx < pts.size()) pts.remove(editIdx);
        savePattern();
        closeEditor();
        refreshMarkers();
        rebuildList();
    }

    private void addClick() {
        if (playing) stopPlay("");
        if (recording) stopRecord();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        long cx = dm.widthPixels / 2;
        long cy = dm.heightPixels / 2;
        pts.add(new long[]{cx, cy, cx, cy, 500, 50, 1, 100});
        savePattern();
        refreshMarkers();
        rebuildList();
        status.setText("Метка #" + pts.size() + " в центре экрана — перетащи её куда нужно");
    }

    private long parse(EditText e, long min, long max, long def) {
        long v;
        try {
            v = Long.parseLong(e.getText().toString().trim());
        } catch (Exception x) {
            v = def;
        }
        return Math.max(min, Math.min(v, max));
    }

    // ===================== ЗАПИСЬ =====================

    private void startRecord() {
        if (playing) stopPlay("");
        closeEditor();
        setPanelFocusable(false);
        pts.clear();
        recording = true;
        passing = false;
        lastUp = SystemClock.uptimeMillis();
        removeMarkers();

        catcher = new View(this);
        catcher.setBackgroundColor(0x2233FF99);
        catcherLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, TYPE,
                NOT_FOCUSABLE | IN_SCREEN, PixelFormat.TRANSLUCENT);
        catcherLp.gravity = Gravity.TOP | Gravity.START;
        fullScreen(catcherLp);
        catcher.setOnTouchListener((v, e) -> {
            onCatch(e);
            return true;
        });
        wm.addView(catcher, catcherLp);
        panelToFront();

        btnRec.setText("■ Закончить запись");
        rebuildList();
    }

    private void stopRecord() {
        recording = false;
        passing = false;
        if (catcher != null) {
            try {
                wm.removeView(catcher);
            } catch (Exception ignored) {
            }
            catcher = null;
        }
        savePattern();
        btnRec.setText("● Записать клики");
        refreshMarkers();
        rebuildList();
    }

    private void onCatch(MotionEvent e) {
        if (passing) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downT = SystemClock.uptimeMillis();
                downX = e.getRawX();
                downY = e.getRawY();
                break;
            case MotionEvent.ACTION_UP:
                long now = SystemClock.uptimeMillis();
                long dur = Math.max(10, Math.min(now - downT, 59000));
                float ux = e.getRawX();
                float uy = e.getRawY();
                if (Math.hypot(ux - downX, uy - downY) < dp(20)) {
                    ux = downX;
                    uy = downY;
                }
                long delay = pts.isEmpty() ? 0 : Math.max(0, downT - lastUp);
                long[] p = {(long) downX, (long) downY, (long) ux, (long) uy, delay, dur, 1, 100};
                pts.add(p);
                addMarker(pts.size() - 1);
                rebuildList();
                passThrough(p);
                break;
        }
    }

    private void passThrough(long[] p) {
        passing = true;
        catcherLp.flags |= NOT_TOUCHABLE;
        wm.updateViewLayout(catcher, catcherLp);
        h.postDelayed(() -> gesture(p, () -> {
            if (catcher != null) {
                catcherLp.flags &= ~NOT_TOUCHABLE;
                wm.updateViewLayout(catcher, catcherLp);
            }
            passing = false;
            lastUp = SystemClock.uptimeMillis();
        }), 60);
    }

    // ===================== ВОСПРОИЗВЕДЕНИЕ =====================

    private void startPlay() {
        if (recording) stopRecord();
        closeEditor();
        if (pts.isEmpty()) {
            if (body.getVisibility() != View.VISIBLE) toggleBody();
            status.setText("Сначала запиши клики или добавь «+ Клик»");
            return;
        }
        cycles = parse(etCycles, 0, Long.MAX_VALUE, 0);
        pause = parse(etPause, 0, 3600000, 500);
        etCycles.setText(String.valueOf(cycles));
        etPause.setText(String.valueOf(pause));
        sp.edit().putLong("repeat", cycles).putLong("pause", pause).apply();
        setPanelFocusable(false);
        playing = true;
        step = 0;
        rep = 0;
        cycle = 0;
        btnPlay.setText("■");
        if (body.getVisibility() == View.VISIBLE) toggleBody();
        refreshMarkers();
        updateStatus();
        h.postDelayed(this::next, 500);
    }

    private void next() {
        if (!playing) return;
        if (step >= pts.size()) {
            step = 0;
            rep = 0;
            cycle++;
            if (cycles > 0 && cycle >= cycles) {
                stopPlay("Готово: " + cycle + " цикл(ов)");
                return;
            }
            paintMarkers();
            updateStatus();
            h.postDelayed(this::next, pause);
            return;
        }
        long[] p = pts.get(step);
        long wait;
        if (rep > 0) wait = p[GAP];
        else if (step == 0 && cycle == 0) wait = 0;
        else wait = p[DELAY];
        paintMarkers();
        updateStatus();
        h.postDelayed(() -> {
            if (!playing) return;
            gesture(p, () -> {
                rep++;
                if (rep >= p[TIMES]) {
                    rep = 0;
                    step++;
                }
                next();
            });
        }, wait);
    }

    private void stopPlay(String msg) {
        playing = false;
        h.removeCallbacksAndMessages(null);
        btnPlay.setText("▶");
        refreshMarkers();
        updateStatus();
        if (msg != null && !msg.isEmpty()) status.setText(msg);
    }

    private void gesture(long[] p, Runnable done) {
        Path path = new Path();
        path.moveTo(Math.max(0, p[X1]), Math.max(0, p[Y1]));
        if (p[X1] != p[X2] || p[Y1] != p[Y2]) path.lineTo(Math.max(0, p[X2]), Math.max(0, p[Y2]));
        long dur = Math.max(10, Math.min(p[DUR], 59000));
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, dur))
                .build();
        boolean ok = dispatchGesture(g, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription d) {
                done.run();
            }

            @Override
            public void onCancelled(GestureDescription d) {
                done.run();
            }
        }, h);
        if (!ok) h.postDelayed(done, 100);
    }

    // ===================== СОХРАНЕНИЕ =====================

    private void savePattern() {
        StringBuilder sb = new StringBuilder();
        for (long[] p : pts) {
            for (int i = 0; i < 8; i++) {
                sb.append(p[i]).append(i < 7 ? ',' : ';');
            }
        }
        sp.edit().putString("pattern", sb.toString()).apply();
    }

    private void loadPattern() {
        pts.clear();
        String s = sp.getString("pattern", "");
        for (String part : s.split(";")) {
            String[] a = part.split(",");
            if (a.length != 6 && a.length != 8) continue;
            try {
                long[] p = {0, 0, 0, 0, 0, 50, 1, 100};
                for (int i = 0; i < a.length; i++) p[i] = Long.parseLong(a[i].trim());
                pts.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
