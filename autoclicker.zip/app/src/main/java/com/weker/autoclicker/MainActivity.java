package com.weker.autoclicker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView info;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(24), dp(32), dp(24), dp(24));
        l.setBackgroundColor(0xFF14141F);

        TextView title = new TextView(this);
        title.setText("АвтоКликер");
        title.setTextSize(26);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        l.addView(title);

        info = new TextView(this);
        info.setTextSize(15);
        info.setTextColor(0xFFDCD6FF);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(16), 0, dp(16));
        l.addView(info);

        Button open = new Button(this);
        open.setText("Открыть «Спец. возможности»");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(open);

        Button show = new Button(this);
        show.setText("Показать панель");
        show.setOnClickListener(v -> {
            if (ClickerService.instance != null) {
                ClickerService.instance.showPanel();
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Сначала включи службу в Спец. возможностях", Toast.LENGTH_LONG).show();
            }
        });
        l.addView(show);

        TextView help = new TextView(this);
        help.setTextSize(14);
        help.setTextColor(0xFFB8B8D0);
        help.setPadding(0, dp(20), 0, 0);
        help.setText(
                "Как пользоваться:\n\n" +
                "1. Нажми «Открыть Спец. возможности» → Скачанные приложения → АвтоКликер → включи.\n" +
                "   Если переключатель серый: Настройки → Приложения → АвтоКликер → ⋮ → «Разрешить ограниченные настройки».\n\n" +
                "2. Появится плавающая панель. Таскай её за «⠿».\n\n" +
                "3. «● Записать клики» — тапай по экрану, каждый тап станет пронумерованной меткой. Или жми «+ Клик» и перетаскивай метку куда нужно.\n\n" +
                "4. Нажми на метку или строку в списке — откроется настройка этого клика: сколько раз нажать подряд, пауза перед ним, интервал между повторами, длительность нажатия.\n\n" +
                "5. «▶» — старт. Текущий клик подсвечивается зелёным и в списке, и на экране. «■» — стоп.\n\n" +
                "Циклов 0 = крутить бесконечно. Метки не мешают кликам, во время работы они прозрачны для нажатий.");
        l.addView(help);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF14141F);
        sv.addView(l);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        info.setText(ClickerService.instance != null
                ? "✅ Служба включена — панель на экране"
                : "❌ Служба выключена — включи её в Спец. возможностях");
    }
}
