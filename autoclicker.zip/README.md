# АвтоКликер — Android + ПК

## Android (AndroidIDE / Acode-сборка)
1. В AndroidIDE: New Project → Empty Activity, язык Java,
   Package name: com.weker.autoclicker, Minimum SDK: 24 (Android 7.0).
2. Скопируй с заменой файлы из папки app/src/main этого архива в app/src/main проекта:
   - AndroidManifest.xml
   - java/com/weker/autoclicker/MainActivity.java
   - java/com/weker/autoclicker/ClickerService.java
   - res/xml/accessibility_config.xml (папку xml создать)
   - res/values/strings.xml
3. В app/build.gradle строка minSdk должна быть: minSdk 24
   (в build.gradle.kts: minSdk = 24)
4. Собери (▶ Run / assembleDebug), установи APK.
5. В приложении: «Открыть Спец. возможности» → АвтоКликер → включить.
   Если переключатель серый (Android 13+): Настройки → Приложения → АвтоКликер → ⋮ →
   «Разрешить ограниченные настройки».

## ПК (Windows / Linux X11 / macOS)
    pip install pynput
    python autoclicker.py
В .exe: pip install pyinstaller && pyinstaller --onefile --noconsole autoclicker.py
F8 — старт/стоп, F9 — запись. Паттерн сохраняется в ~/autoclicker_pattern.json
