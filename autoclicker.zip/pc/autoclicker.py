import json
import math
import os
import queue
import threading
import time
import tkinter as tk

from pynput import keyboard, mouse

try:
    import ctypes
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

SAVE = os.path.join(os.path.expanduser("~"), "autoclicker_pattern.json")
BTN = {"left": mouse.Button.left, "right": mouse.Button.right, "middle": mouse.Button.middle}

BG = "#1b1b2a"
FG = "#ffffff"
SUB = "#b8b8d0"
FIELD = "#2c2c42"


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("АвтоКликер")
        self.root.attributes("-topmost", True)
        self.root.resizable(False, False)
        self.root.configure(bg=BG, padx=12, pady=10)

        self.pts = []
        self.recording = False
        self.playing = False
        self.stop_evt = threading.Event()
        self.cmds = queue.Queue()
        self.listener = None
        self.down = None
        self.last_up = 0.0
        self.geom = (0, 0, 0, 0)
        self.cycle = 0
        self.step = 0
        self.repeat = 0
        self.msg = ""
        self.ctrl = mouse.Controller()

        self.v_delay = tk.StringVar(value="0")
        self.v_repeat = tk.StringVar(value="0")
        self.v_pause = tk.StringVar(value="500")
        self.load()

        self.status = tk.Label(self.root, text="", bg=BG, fg="#dcd6ff", font=("Segoe UI", 10), wraplength=250, justify="left")
        self.status.pack(fill="x", pady=(0, 8))

        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x")
        self.b_rec = self.button(row, "● Запись (F9)", "#b23a48", lambda: self.cmds.put("rec"))
        self.b_rec.pack(side="left", expand=True, fill="x", padx=(0, 4))
        self.b_play = self.button(row, "▶ Старт (F8)", "#2e9e5b", lambda: self.cmds.put("play"))
        self.b_play.pack(side="left", expand=True, fill="x")

        self.field("Задержка между кликами, мс (0 = как записал)", self.v_delay)
        self.field("Сколько циклов (0 = бесконечно)", self.v_repeat)
        self.field("Пауза между циклами, мс", self.v_pause)

        self.button(self.root, "Очистить паттерн", "#3a3a55", lambda: self.cmds.put("clear")).pack(fill="x", pady=(10, 0))
        tk.Label(self.root, text="F8 — старт/стоп, F9 — запись. Работают из любого окна.",
                 bg=BG, fg=SUB, font=("Segoe UI", 8)).pack(pady=(8, 0))

        self.hot = keyboard.GlobalHotKeys({"<f8>": lambda: self.cmds.put("play"),
                                           "<f9>": lambda: self.cmds.put("rec")})
        self.hot.start()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)
        self.tick()

    def button(self, parent, text, color, cmd):
        return tk.Button(parent, text=text, command=cmd, bg=color, fg=FG, activebackground=color,
                         activeforeground=FG, relief="flat", font=("Segoe UI", 10, "bold"), padx=8, pady=6)

    def field(self, label, var):
        tk.Label(self.root, text=label, bg=BG, fg=SUB, font=("Segoe UI", 9), anchor="w").pack(fill="x", pady=(8, 2))
        tk.Entry(self.root, textvariable=var, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                 font=("Segoe UI", 11)).pack(fill="x", ipady=4)

    def num(self, var):
        try:
            v = int(var.get().strip())
        except ValueError:
            v = 0
        v = max(0, v)
        var.set(str(v))
        return v

    def tick(self):
        r = self.root
        self.geom = (r.winfo_rootx(), r.winfo_rooty(), r.winfo_rootx() + r.winfo_width(), r.winfo_rooty() + r.winfo_height())
        while not self.cmds.empty():
            c = self.cmds.get()
            if c == "rec":
                self.stop_record() if self.recording else self.start_record()
            elif c == "play":
                self.stop_play("Остановлено") if self.playing else self.start_play()
            elif c == "clear":
                self.stop_play("")
                self.pts = []
                self.save()
        if self.recording:
            s = f"Запись… кликай где нужно. Точек: {len(self.pts)}"
        elif self.playing:
            s = f"Цикл {self.cycle + 1}/{self.repeat or '∞'}   клик {min(self.step + 1, len(self.pts))}/{len(self.pts)}"
        else:
            s = self.msg or f"Точек в паттерне: {len(self.pts)}"
        self.status.config(text=s)
        self.b_rec.config(text="■ Стоп запись (F9)" if self.recording else "● Запись (F9)")
        self.b_play.config(text="■ Стоп (F8)" if self.playing else "▶ Старт (F8)")
        r.after(100, self.tick)

    def inside(self, x, y):
        x1, y1, x2, y2 = self.geom
        return x1 <= x <= x2 and y1 <= y <= y2

    def start_record(self):
        self.stop_play("")
        self.msg = ""
        self.pts = []
        self.last_up = time.time()
        self.down = None
        self.recording = True
        self.listener = mouse.Listener(on_click=self.on_click)
        self.listener.start()

    def stop_record(self):
        self.recording = False
        if self.listener:
            self.listener.stop()
            self.listener = None
        self.save()

    def on_click(self, x, y, button, pressed):
        if not self.recording or self.inside(x, y):
            return
        now = time.time()
        if pressed:
            self.down = (now, x, y)
            return
        if not self.down:
            return
        t0, x0, y0 = self.down
        self.down = None
        if math.hypot(x - x0, y - y0) < 10:
            x, y = x0, y0
        delay = 0 if not self.pts else max(0.0, t0 - self.last_up)
        name = {mouse.Button.right: "right", mouse.Button.middle: "middle"}.get(button, "left")
        self.pts.append({"x": x0, "y": y0, "x2": x, "y2": y, "b": name,
                         "delay": round(delay, 3), "hold": round(min(max(now - t0, 0.01), 30), 3)})
        self.last_up = now

    def start_play(self):
        if self.recording:
            self.stop_record()
        if not self.pts:
            self.msg = "Сначала запиши паттерн (F9)"
            return
        self.msg = ""
        self.fixed = self.num(self.v_delay) / 1000
        self.repeat = self.num(self.v_repeat)
        self.pause = self.num(self.v_pause) / 1000
        self.save()
        self.stop_evt.clear()
        self.playing = True
        self.cycle = 0
        self.step = 0
        threading.Thread(target=self.loop, daemon=True).start()

    def stop_play(self, msg):
        if self.playing:
            self.msg = msg
        self.playing = False
        self.stop_evt.set()

    def wait(self, sec):
        return not self.stop_evt.wait(sec)

    def loop(self):
        pts = list(self.pts)
        if not self.wait(0.5):
            return
        while self.playing:
            for i, p in enumerate(pts):
                self.step = i
                w = 0 if i == 0 else (self.fixed if self.fixed > 0 else p["delay"])
                if not self.wait(w):
                    return
                self.do(p)
            self.cycle += 1
            if self.repeat and self.cycle >= self.repeat:
                self.msg = f"Готово: {self.cycle} цикл(ов)"
                self.playing = False
                return
            if not self.wait(self.pause):
                return

    def do(self, p):
        b = BTN[p["b"]]
        self.ctrl.position = (p["x"], p["y"])
        time.sleep(0.02)
        self.ctrl.press(b)
        hold = p["hold"]
        if (p["x"], p["y"]) != (p["x2"], p["y2"]):
            steps = max(5, int(hold / 0.01))
            for k in range(1, steps + 1):
                self.ctrl.position = (p["x"] + (p["x2"] - p["x"]) * k / steps,
                                      p["y"] + (p["y2"] - p["y"]) * k / steps)
                time.sleep(hold / steps)
        else:
            time.sleep(min(hold, 30))
        self.ctrl.release(b)

    def save(self):
        data = {"pts": self.pts, "delay": self.v_delay.get(), "repeat": self.v_repeat.get(), "pause": self.v_pause.get()}
        try:
            with open(SAVE, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except OSError:
            pass

    def load(self):
        try:
            with open(SAVE, encoding="utf-8") as f:
                d = json.load(f)
            self.pts = d.get("pts", [])
            self.v_delay.set(d.get("delay", "0"))
            self.v_repeat.set(d.get("repeat", "0"))
            self.v_pause.set(d.get("pause", "500"))
        except (OSError, ValueError):
            pass

    def quit(self):
        self.stop_play("")
        if self.recording:
            self.stop_record()
        self.hot.stop()
        self.root.destroy()


if __name__ == "__main__":
    App().root.mainloop()
